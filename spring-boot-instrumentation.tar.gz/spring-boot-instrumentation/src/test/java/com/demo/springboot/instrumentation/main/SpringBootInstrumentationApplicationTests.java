package com.demo.springboot.instrumentation.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootInstrumentationApplicationTests {

	@Test
	void contextLoads() {
	}

}
