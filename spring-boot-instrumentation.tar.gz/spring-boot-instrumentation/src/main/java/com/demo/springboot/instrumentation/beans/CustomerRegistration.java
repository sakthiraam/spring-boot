package com.demo.springboot.instrumentation.beans;

import java.util.ArrayList;
import java.util.List;

public class CustomerRegistration {
    public List<Customer> customerRecords;
    private static CustomerRegistration stdregd = null;
    private CustomerRegistration(){
        customerRecords = new ArrayList <Customer>();
    }
    public static CustomerRegistration getInstance() {
        if(stdregd == null) {
            stdregd = new CustomerRegistration();
            return stdregd;
        }
        else {
            return stdregd;
        }
    }
    public void add(Customer std) {
        customerRecords.add(std);
    }
    public String upDateCustomer(Customer std) {
        for(int i = 0; i< customerRecords.size(); i++)
        {
            Customer stdn = customerRecords.get(i);
            if(stdn.getRegistrationNumber().equals(std.getRegistrationNumber())) {
                customerRecords.set(i, std);//update the new record
                return "Update successful";
            }
        }
        return "Update un-successful";
    }
    public String deleteCustomer(String registrationNumber) {
        for(int i = 0; i< customerRecords.size(); i++)
        {
            Customer stdn = customerRecords.get(i);
            if(stdn.getRegistrationNumber().equals(registrationNumber)){
                customerRecords.remove(i);//update the new record
                return "Delete successful";
            }
        }
        return "Delete un-successful";
    }
    public List<Customer> getCustomerRecords() {
        return customerRecords;
    }
}



