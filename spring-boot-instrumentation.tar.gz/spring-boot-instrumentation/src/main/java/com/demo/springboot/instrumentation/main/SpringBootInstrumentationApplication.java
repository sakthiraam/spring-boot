package com.demo.springboot.instrumentation.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.demo"})
public class SpringBootInstrumentationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootInstrumentationApplication.class, args);
	}

}
