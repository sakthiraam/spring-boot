package com.demo.springboot.instrumentation.controllers;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.demo.springboot.instrumentation.beans.*;
import io.micrometer.core.instrument.Counter;

import javax.annotation.PostConstruct;


@Controller //This is a REST Web Service
public class CustomerRegistrationController {
    @Autowired
    private MeterRegistry meterRegistry;
    private Counter totalRegistration;
    @PostConstruct
    private void initOrderCounters() {
        totalRegistration = Counter.builder("total_registration_count")
                .tag("type", "customer")
                .description("Total number of registration")
                .register(meterRegistry);
    }

    @RequestMapping(method = RequestMethod.POST, value="/register/customer")
    @ResponseBody
    public CustomerRegistrationReply registerCustomer(@RequestBody Customer customer) {
            System.out.println("In registerCustomer");
            CustomerRegistrationReply stdregreply = new CustomerRegistrationReply();
            CustomerRegistration.getInstance().add(customer);
            //We are setting the below value just to reply a message back to the caller
            stdregreply.setName(customer.getName());
            stdregreply.setAge(customer.getAge());
            stdregreply.setRegistrationNumber(customer.getRegistrationNumber());
            stdregreply.setRegistrationStatus("Successful");
            totalRegistration.increment();
            return stdregreply;


        }

    }