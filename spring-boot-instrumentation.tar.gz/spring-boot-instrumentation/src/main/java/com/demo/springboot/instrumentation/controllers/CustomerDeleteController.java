package com.demo.springboot.instrumentation.controllers;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.PathVariable;
import com.demo.springboot.instrumentation.beans.CustomerRegistration;

import javax.annotation.PostConstruct;
import java.util.Collection;

@Controller
public class CustomerDeleteController {
    @Autowired
    private MeterRegistry meterRegistry;
    private Counter totalRegistration;
    @PostConstruct
    private void initOrderCounters() {
        Gauge.builder("current_registration_count", CustomerRegistration.getInstance().customerRecords, Collection::size)
                .description("Current registration count")
                .register(meterRegistry);
    }
    @RequestMapping(method = RequestMethod.DELETE, value="/delete/customer/{regdNum}")
    @ResponseBody
    public String deleteCustomerRecord(@PathVariable("regdNum") String regdNum) {
        System.out.println("In deleteCustomerRecord");

        return CustomerRegistration.getInstance().deleteCustomer(regdNum);
    }
}
