package com.demo.springboot.instrumentation.controllers;


import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.demo.springboot.instrumentation.beans.Customer;
import com.demo.springboot.instrumentation.beans.CustomerRegistration;

@Controller
public class CustomerRetrieveController {
    //The @RequestMapping annotation maps all HTTP operations by default and, in this example,
    // it ensures that HTTP requests to /customer/allcustomer are mapped to the getAllCustomers() method.
    @RequestMapping(method = RequestMethod.GET, value="/customer/allcustomer")
    @ResponseBody
    public List<Customer> getAllCustomers() {
        return CustomerRegistration.getInstance().getCustomerRecords();
    }
}
