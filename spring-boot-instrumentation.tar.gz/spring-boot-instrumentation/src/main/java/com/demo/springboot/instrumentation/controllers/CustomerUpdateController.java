package com.demo.springboot.instrumentation.controllers;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.demo.springboot.instrumentation.beans.Customer;
import com.demo.springboot.instrumentation.beans.CustomerRegistration;

import javax.annotation.PostConstruct;
import java.util.Collection;

@Controller
public class CustomerUpdateController {

    @RequestMapping(method = RequestMethod.PUT, value="/update/customer")
    @ResponseBody
    public String updateCustomerRecord(@RequestBody Customer stdn) {
        System.out.println("In updateCustomerRecord");
        return CustomerRegistration.getInstance().upDateCustomer(stdn);
    }
}